"""
Integration tests for complete user workflows
Tests end-to-end scenarios including:
- User browsing products and viewing predictions
- Admin managing produ